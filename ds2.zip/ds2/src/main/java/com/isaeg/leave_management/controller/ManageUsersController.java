package com.isaeg.leave_management.controller;
import com.isaeg.leave_management.dao.UserDAO;
import com.isaeg.leave_management.dao.UserDAOImpl;
import com.isaeg.leave_management.model.User;
import javafx.beans.binding.Bindings;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.FXCollections;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
public class ManageUsersController {
    @FXML private TableView<User> usersTable;
    @FXML private TableColumn<User, Integer> userIdColumn;
    @FXML private TableColumn<User, String> usernameColumn;
    @FXML private TableColumn<User, String> roleColumn;
    @FXML private TextField usernameField;
    @FXML private TextField passwordField;
    @FXML private TextField roleField;
    @FXML private Button createButton;
    @FXML private Button updateButton;
    @FXML private Button deleteButton;
    @FXML private Label errorLabel;
    @FXML private Label successLabel;
    private final UserDAO userDAO = new UserDAOImpl();
    private User currentUser;
    private static final List<String> VALID_ROLES = Arrays.asList("TEACHER", "STAFF", "HR", "ADMIN");
    public void setUser(User user) {
        this.currentUser = user;
        System.out.println("Setting user: " + (user != null ? user.getUsername() : "null")); // Debug
        loadUsers();
    }
    private void loadUsers() {
        try {
            System.out.println("Loading users..."); // Debug
            List<User> users = userDAO.getAllUsers();
            System.out.println("Fetched " + users.size() + " users"); // Debug
            userIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
            usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
            roleColumn.setCellValueFactory(new PropertyValueFactory<>("role"));
            usersTable.setItems(FXCollections.observableArrayList(users));
            // Enable buttons when a user is selected
            updateButton.disableProperty().bind(usersTable.getSelectionModel().selectedItemProperty().isNull());
            deleteButton.disableProperty().bind(usersTable.getSelectionModel().selectedItemProperty().isNull());
            // Populate fields on selection
            usersTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
                if (newSelection != null) {
                    usernameField.setText(newSelection.getUsername());
                    passwordField.setText(newSelection.getPassword());
                    roleField.setText(newSelection.getRole());
                } else {
                    clearFields();
                }
            });
        } catch (SQLException e) {
            errorLabel.setText("Error loading users: " + e.getMessage());
            System.err.println("SQLException in loadUsers: " + e.getMessage());
            e.printStackTrace();
        }
    }
    @FXML
    private void handleCreate(ActionEvent event) {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();
        String role = roleField.getText().trim().toUpperCase();
        if (username.isEmpty() || password.isEmpty() || role.isEmpty()) {
            errorLabel.setText("All fields are required");
            return;
        }
        if (!VALID_ROLES.contains(role)) {
            errorLabel.setText("Invalid role. Use: " + String.join(", ", VALID_ROLES));
            return;
        }
        try {
            User existingUser = userDAO.getUserByUsername(username);
            if (existingUser != null) {
                errorLabel.setText("Username already exists");
                return;
            }
            User newUser = new User(0, username, password, role);
            userDAO.createUser(newUser);
            successLabel.setText("User created successfully!");
            errorLabel.setText("");
            clearFields();
            loadUsers();
        } catch (SQLException e) {
            errorLabel.setText("Create failed: " + e.getMessage());
            successLabel.setText("");
            System.err.println("SQLException in handleCreate: " + e.getMessage());
        }
    }
    @FXML
    private void handleUpdate(ActionEvent event) {
        User selectedUser = usersTable.getSelectionModel().getSelectedItem();
        if (selectedUser == null) {
            errorLabel.setText("Please select a user");
            return;
        }
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();
        String role = roleField.getText().trim().toUpperCase();
        if (username.isEmpty() || password.isEmpty() || role.isEmpty()) {
            errorLabel.setText("All fields are required");
            return;
        }
        if (!VALID_ROLES.contains(role)) {
            errorLabel.setText("Invalid role. Use: " + String.join(", ", VALID_ROLES));
            return;
        }
        try {
            User existingUser = userDAO.getUserByUsername(username);
            if (existingUser != null && existingUser.getId() != selectedUser.getId()) {
                errorLabel.setText("Username already exists");
                return;
            }
            selectedUser.setUsername(username);
            selectedUser.setPassword(password);
            selectedUser.setRole(role);
            userDAO.updateUser(selectedUser);
            successLabel.setText("User updated successfully!");
            errorLabel.setText("");
            clearFields();
            loadUsers();
        } catch (SQLException e) {
            errorLabel.setText("Update failed: " + e.getMessage());
            successLabel.setText("");
            System.err.println("SQLException in handleUpdate: " + e.getMessage());
        }
    }
    @FXML
    private void handleDelete(ActionEvent event) {
        User selectedUser = usersTable.getSelectionModel().getSelectedItem();
        if (selectedUser == null) {
            errorLabel.setText("Please select a user");
            return;
        }
        if (selectedUser.getId() == currentUser.getId()) {
            errorLabel.setText("Cannot delete current user");
            return;
        }
        try {
            userDAO.deleteUser(selectedUser.getId());
            successLabel.setText("User deleted successfully!");
            errorLabel.setText("");
            clearFields();
            loadUsers();
        } catch (SQLException e) {
            errorLabel.setText("Delete failed: " + e.getMessage());
            successLabel.setText("");
            System.err.println("SQLException in handleDelete: " + e.getMessage());
        }
    }
    @FXML
    private void handleBack(ActionEvent event) {
        try {
            System.out.println("Returning to dashboard"); // Debug
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/isaeg/leave_management/fxml/dashboard.fxml"));
            Parent dashboardParent = loader.load();
            DashboardController controller = loader.getController();
            controller.setUserInfo(currentUser.getUsername(), currentUser.getRole());
            Scene dashboardScene = new Scene(dashboardParent, 800, 600);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(dashboardScene);
            stage.setTitle("Leave Management System - Dashboard");
            stage.show();
        } catch (IOException e) {
            errorLabel.setText("Error loading dashboard: " + e.getMessage());
            System.err.println("IOException in handleBack: " + e.getMessage());
        }
    }
    private void clearFields() {
        usernameField.clear();
        passwordField.clear();
        roleField.clear();
    }
}