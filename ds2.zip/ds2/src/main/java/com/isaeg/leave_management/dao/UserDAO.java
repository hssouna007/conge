package com.isaeg.leave_management.dao;
import com.isaeg.leave_management.model.User;
import java.sql.SQLException;
import java.util.List;

public interface UserDAO {
    void createUser(User user) throws SQLException;
    User getUserByUsername(String username) throws SQLException;
    User getUserById(int userId) throws SQLException;
    void updateUser(User user) throws SQLException;
    void deleteUser(int userId) throws SQLException;


    List<User> getAllUsers() throws SQLException;
}