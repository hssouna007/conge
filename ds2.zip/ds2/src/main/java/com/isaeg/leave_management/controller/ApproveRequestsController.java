package com.isaeg.leave_management.controller;
import com.isaeg.leave_management.dao.LeaveRequestDAO;
import com.isaeg.leave_management.dao.LeaveRequestDAOImpl;
import com.isaeg.leave_management.dao.UserDAO;
import com.isaeg.leave_management.dao.UserDAOImpl;
import com.isaeg.leave_management.model.LeaveRequest;
import com.isaeg.leave_management.model.User;
import javafx.beans.binding.Bindings;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.FXCollections;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
public class ApproveRequestsController {
    @FXML private TableView<LeaveRequest> requestsTable;
    @FXML private TableColumn<LeaveRequest, Integer> requestIdColumn;
    @FXML private TableColumn<LeaveRequest, String> usernameColumn;
    @FXML private TableColumn<LeaveRequest, String> leaveTypeColumn;
    @FXML private TableColumn<LeaveRequest, LocalDate> startDateColumn;
    @FXML private TableColumn<LeaveRequest, LocalDate> endDateColumn;
    @FXML private TableColumn<LeaveRequest, String> reasonColumn;
    @FXML private TableColumn<LeaveRequest, LocalDateTime> submittedAtColumn;
    @FXML private TextField rejectionReasonField;
    @FXML private Button approveButton;
    @FXML private Button rejectButton;
    @FXML private Label errorLabel;
    @FXML private Label successLabel;
    private final LeaveRequestDAO leaveRequestDAO = new LeaveRequestDAOImpl();
    private final UserDAO userDAO = new UserDAOImpl();
    private User currentUser;
    public void setUser(User user) {
        this.currentUser = user;
        System.out.println("Setting user: " + (user != null ? user.getUsername() : "null")); // Debug
        loadPendingRequests();
    }
    private void loadPendingRequests() {
        try {
            System.out.println("Loading pending requests..."); // Debug
            List<LeaveRequest> requests = leaveRequestDAO.getAllPendingRequests();
            System.out.println("Fetched " + requests.size() + " pending requests"); // Debug
            for (LeaveRequest req : requests) {
                System.out.println("Request: ID=" + req.getRequestId() + ", Type=" + req.getLeaveType() + ", Start=" + req.getStartDate()); // Debug
            }
            requestIdColumn.setCellValueFactory(new PropertyValueFactory<>("requestId"));
            usernameColumn.setCellValueFactory(cellData -> {
                try {
                    int userId = cellData.getValue().getUserId();
                    System.out.println("Fetching username for user_id: " + userId); // Debug
                    User user = userDAO.getUserById(userId);
                    return Bindings.createStringBinding(() -> user != null ? user.getUsername() : "Unknown");
                } catch (SQLException e) {
                    System.err.println("SQLException in usernameColumn: " + e.getMessage()); // Debug
                    return Bindings.createStringBinding(() -> "Error");
                }
            });
            leaveTypeColumn.setCellValueFactory(new PropertyValueFactory<>("leaveType"));
            startDateColumn.setCellValueFactory(new PropertyValueFactory<>("startDate"));
            endDateColumn.setCellValueFactory(new PropertyValueFactory<>("endDate"));
            reasonColumn.setCellValueFactory(new PropertyValueFactory<>("reason"));
            submittedAtColumn.setCellValueFactory(new PropertyValueFactory<>("submittedAt"));
            requestsTable.setItems(FXCollections.observableArrayList(requests));
            // Enable buttons when a request is selected
            approveButton.disableProperty().bind(requestsTable.getSelectionModel().selectedItemProperty().isNull());
            rejectButton.disableProperty().bind(requestsTable.getSelectionModel().selectedItemProperty().isNull());
        } catch (SQLException e) {
            errorLabel.setText("Error loading requests: " + e.getMessage());
            System.err.println("SQLException in loadPendingRequests: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            errorLabel.setText("Unexpected error: " + e.getMessage());
            System.err.println("Unexpected error in loadPendingRequests: " + e.getMessage());
            e.printStackTrace();
        }
    }
    @FXML
    private void handleApprove(ActionEvent event) {
        LeaveRequest selectedRequest = requestsTable.getSelectionModel().getSelectedItem();
        if (selectedRequest == null) {
            errorLabel.setText("Please select a request");
            return;
        }
        try {
            System.out.println("Approving request_id: " + selectedRequest.getRequestId()); // Debug
            selectedRequest.setStatus("APPROVED");
            selectedRequest.setRejectionReason(null);
            selectedRequest.setProcessedAt(LocalDateTime.now());
            leaveRequestDAO.updateLeaveRequest(selectedRequest);
            successLabel.setText("Request approved successfully!");
            errorLabel.setText("");
            loadPendingRequests(); // Refresh table
        } catch (SQLException e) {
            errorLabel.setText("Approval failed: " + e.getMessage());
            successLabel.setText("");
            System.err.println("SQLException in handleApprove: " + e.getMessage());
        }
    }
    @FXML
    private void handleReject(ActionEvent event) {
        LeaveRequest selectedRequest = requestsTable.getSelectionModel().getSelectedItem();
        if (selectedRequest == null) {
            errorLabel.setText("Please select a request");
            return;
        }
        String rejectionReason = rejectionReasonField.getText().trim();
        try {
            System.out.println("Rejecting request_id: " + selectedRequest.getRequestId()); // Debug
            selectedRequest.setStatus("REJECTED");
            selectedRequest.setRejectionReason(rejectionReason.isEmpty() ? null : rejectionReason);
            selectedRequest.setProcessedAt(LocalDateTime.now());
            leaveRequestDAO.updateLeaveRequest(selectedRequest);
            successLabel.setText("Request rejected successfully!");
            errorLabel.setText("");
            rejectionReasonField.clear();
            loadPendingRequests(); // Refresh table
        } catch (SQLException e) {
            errorLabel.setText("Rejection failed: " + e.getMessage());
            successLabel.setText("");
            System.err.println("SQLException in handleReject: " + e.getMessage());
        }
    }
    @FXML
    private void handleBack(ActionEvent event) {
        try {
            System.out.println("Returning to dashboard"); // Debug
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/isaeg/leave_management/fxml/dashboard.fxml"));
            Parent dashboardParent = loader.load();
            DashboardController controller = loader.getController();
            controller.setUserInfo(currentUser.getUsername(), currentUser.getRole());
            Scene dashboardScene = new Scene(dashboardParent, 800, 600);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(dashboardScene);
            stage.setTitle("Leave Management System - Dashboard");
            stage.show();
        } catch (IOException e) {
            errorLabel.setText("Error loading dashboard: " + e.getMessage());
            System.err.println("IOException in handleBack: " + e.getMessage());
        }
    }
}