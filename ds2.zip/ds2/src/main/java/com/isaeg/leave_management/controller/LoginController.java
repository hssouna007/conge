package com.isaeg.leave_management.controller;
import com.isaeg.leave_management.dao.UserDAO;
import com.isaeg.leave_management.dao.UserDAOImpl;
import com.isaeg.leave_management.model.User;
import com.isaeg.leave_management.util.PasswordUtil;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;
import java.io.IOException;
import java.sql.SQLException;
public class LoginController {
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Button loginButton;
    @FXML private Button registerButton;
    @FXML private Label errorLabel;
    private final UserDAO userDAO = new UserDAOImpl();
    @FXML
    private void handleLogin(ActionEvent event) {
        String username = usernameField.getText().trim();
        String password = passwordField.getText();
        try {
            User user = userDAO.getUserByUsername(username);
            if (user != null && PasswordUtil.checkPassword(password, user.getPassword())) {
                // Navigate to dashboard
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/isaeg/leave_management/fxml/dashboard.fxml"));
                Parent dashboardParent = loader.load();
                DashboardController controller = loader.getController();
                controller.setUserInfo(user.getUsername(), user.getRole());
                Scene dashboardScene = new Scene(dashboardParent, 800, 600);
                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stage.setScene(dashboardScene);
                stage.setTitle("Leave Management System - Dashboard");
                stage.show();
            } else {
                errorLabel.setText("Invalid username or password");
            }
        } catch (IOException e) {
            errorLabel.setText("Error loading dashboard: " + e.getMessage());
        } catch (SQLException e) {
            errorLabel.setText("Database error: " + e.getMessage());
        }
    }
    @FXML
    private void handleRegister(ActionEvent event) {
        try {
            Parent registerParent = FXMLLoader.load(getClass().getResource("/com/isaeg/leave_management/fxml/register.fxml"));
            Scene registerScene = new Scene(registerParent, 600, 400);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(registerScene);
            stage.setTitle("Leave Management System - Register");
            stage.show();
        } catch (IOException e) {
            errorLabel.setText("Error loading register: " + e.getMessage());
        }
    }
}