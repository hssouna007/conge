package com.isaeg.leave_management.dao;
import com.isaeg.leave_management.model.LeaveBalance;
import com.isaeg.leave_management.db.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
public class LeaveBalanceDAOImpl implements LeaveBalanceDAO {
    @Override
    public List<LeaveBalance> getLeaveBalancesByUserId(int userId) throws SQLException {
        String sql = "SELECT * FROM leave_balances WHERE user_id = ?";
        List<LeaveBalance> balances = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                balances.add(new LeaveBalance(
                        rs.getInt("balance_id"),
                        rs.getInt("user_id"),
                        rs.getString("leave_type"),
                        rs.getInt("balance"),
                        rs.getTimestamp("updated_at").toLocalDateTime()
                ));
            }
            return balances;
        }
    }
}