package com.isaeg.leave_management.controller;
import com.isaeg.leave_management.dao.LeaveBalanceDAO;
import com.isaeg.leave_management.dao.LeaveBalanceDAOImpl;
import com.isaeg.leave_management.model.LeaveBalance;
import com.isaeg.leave_management.model.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.FXCollections;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;

public class ViewBalancesController {
    @FXML private TableView<LeaveBalance> balancesTable;
    @FXML private TableColumn<LeaveBalance, String> leaveTypeColumn;
    @FXML private TableColumn<LeaveBalance, Integer> balanceColumn;
    @FXML private TableColumn<LeaveBalance, LocalDateTime> updatedAtColumn;
    @FXML private Button backButton;
    @FXML private Label errorLabel;
    private final LeaveBalanceDAO leaveBalanceDAO = new LeaveBalanceDAOImpl();
    private User currentUser;
    public void setUser(User user) {
        this.currentUser = user;
        System.out.println("Setting user: " + (user != null ? user.getUsername() : "null")); // Debug
        loadBalances();
    }
    private void loadBalances() {
        try {
            System.out.println("Loading balances for user_id: " + currentUser.getId()); // Debug
            List<LeaveBalance> balances = leaveBalanceDAO.getLeaveBalancesByUserId(currentUser.getId());
            System.out.println("Fetched " + balances.size() + " balances"); // Debug
            leaveTypeColumn.setCellValueFactory(new PropertyValueFactory<>("leaveType"));
            balanceColumn.setCellValueFactory(new PropertyValueFactory<>("balance"));
            updatedAtColumn.setCellValueFactory(new PropertyValueFactory<>("updatedAt"));
            balancesTable.setItems(FXCollections.observableArrayList(balances));
        } catch (SQLException e) {
            errorLabel.setText("Error loading balances: " + e.getMessage());
            System.err.println("SQLException in loadBalances: " + e.getMessage());
            e.printStackTrace();
        }
    }
    @FXML
    private void handleBack(ActionEvent event) {
        try {
            System.out.println("Returning to dashboard"); // Debug
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/isaeg/leave_management/fxml/dashboard.fxml"));
            Parent dashboardParent = loader.load();
            DashboardController controller = loader.getController();
            controller.setUserInfo(currentUser.getUsername(), currentUser.getRole());
            Scene dashboardScene = new Scene(dashboardParent, 800, 600);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(dashboardScene);
            stage.setTitle("Leave Management System - Dashboard");
            stage.show();
        } catch (IOException e) {
            errorLabel.setText("Error loading dashboard: " + e.getMessage());
            System.err.println("IOException in handleBack: " + e.getMessage());
        }
    }
}