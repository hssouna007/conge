package com.isaeg.leave_management.model;
import java.time.LocalDateTime;
public class LeaveBalance {
    private int balanceId;
    private int userId;
    private String leaveType;
    private int balance;
    private LocalDateTime updatedAt;
    public LeaveBalance(int balanceId, int userId, String leaveType, int balance, LocalDateTime updatedAt) {
        this.balanceId = balanceId;
        this.userId = userId;
        this.leaveType = leaveType;
        this.balance = balance;
        this.updatedAt = updatedAt;
    }
    // Getters and Setters
    public int getBalanceId() { return balanceId; }
    public void setBalanceId(int balanceId) { this.balanceId = balanceId; }
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    public String getLeaveType() { return leaveType; }
    public void setLeaveType(String leaveType) { this.leaveType = leaveType; }
    public int getBalance() { return balance; }
    public void setBalance(int balance) { this.balance = balance; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}