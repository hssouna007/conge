package com.isaeg.leave_management.dao;
import com.isaeg.leave_management.model.LeaveRequest;
import com.isaeg.leave_management.db.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
public class LeaveRequestDAOImpl implements LeaveRequestDAO {
    @Override
    public void createLeaveRequest(LeaveRequest request) throws SQLException {
        String sql = "INSERT INTO leave_requests (user_id, leave_type, start_date, end_date, status, reason) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, request.getUserId());
            stmt.setString(2, request.getLeaveType());
            stmt.setDate(3, java.sql.Date.valueOf(request.getStartDate()));
            stmt.setDate(4, java.sql.Date.valueOf(request.getEndDate()));
            stmt.setString(5, request.getStatus());
            stmt.setString(6, request.getReason());
            stmt.executeUpdate();
        }
    }
    @Override
    public LeaveRequest getLeaveRequestById(int requestId) throws SQLException {
        String sql = "SELECT * FROM leave_requests WHERE request_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, requestId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new LeaveRequest(
                        rs.getInt("request_id"),
                        rs.getInt("user_id"),
                        rs.getString("leave_type"),
                        rs.getDate("start_date").toLocalDate(),
                        rs.getDate("end_date").toLocalDate(),
                        rs.getString("reason"),
                        rs.getString("status"),
                        rs.getString("rejection_reason"),
                        rs.getTimestamp("submitted_at") != null ? rs.getTimestamp("submitted_at").toLocalDateTime() : null,
                        rs.getTimestamp("processed_at") != null ? rs.getTimestamp("processed_at").toLocalDateTime() : null
                );
            }
            return null;
        }
    }
    @Override
    public List<LeaveRequest> getLeaveRequestsByUserId(int userId) throws SQLException {
        String sql = "SELECT * FROM leave_requests WHERE user_id = ?";
        List<LeaveRequest> requests = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                requests.add(new LeaveRequest(
                        rs.getInt("request_id"),
                        rs.getInt("user_id"),
                        rs.getString("leave_type"),
                        rs.getDate("start_date").toLocalDate(),
                        rs.getDate("end_date").toLocalDate(),
                        rs.getString("reason"),
                        rs.getString("status"),
                        rs.getString("rejection_reason"),
                        rs.getTimestamp("submitted_at") != null ? rs.getTimestamp("submitted_at").toLocalDateTime() : null,
                        rs.getTimestamp("processed_at") != null ? rs.getTimestamp("processed_at").toLocalDateTime() : null
                ));
            }
            return requests;
        }
    }
    @Override
    public List<LeaveRequest> getAllPendingRequests() throws SQLException {
        String sql = "SELECT * FROM leave_requests WHERE status = 'PENDING'";
        List<LeaveRequest> requests = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                requests.add(new LeaveRequest(
                        rs.getInt("request_id"),
                        rs.getInt("user_id"),
                        rs.getString("leave_type"),
                        rs.getDate("start_date").toLocalDate(),
                        rs.getDate("end_date").toLocalDate(),
                        rs.getString("reason"),
                        rs.getString("status"),
                        rs.getString("rejection_reason"),
                        rs.getTimestamp("submitted_at") != null ? rs.getTimestamp("submitted_at").toLocalDateTime() : null,
                        rs.getTimestamp("processed_at") != null ? rs.getTimestamp("processed_at").toLocalDateTime() : null
                ));
            }
            return requests;
        }
    }
    @Override
    public void updateLeaveRequest(LeaveRequest request) throws SQLException {
        String sql = "UPDATE leave_requests SET leave_type = ?, start_date = ?, end_date = ?, reason = ?, status = ?, rejection_reason = ?, processed_at = ? WHERE request_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, request.getLeaveType());
            stmt.setDate(2, java.sql.Date.valueOf(request.getStartDate()));
            stmt.setDate(3, java.sql.Date.valueOf(request.getEndDate()));
            stmt.setString(4, request.getReason());
            stmt.setString(5, request.getStatus());
            stmt.setString(6, request.getRejectionReason());
            stmt.setObject(7, request.getProcessedAt() != null ? java.sql.Timestamp.valueOf(request.getProcessedAt()) : null);
            stmt.setInt(8, request.getRequestId());
            stmt.executeUpdate();
        }
    }
    @Override
    public void deleteLeaveRequest(int requestId) throws SQLException {
        String sql = "DELETE FROM leave_requests WHERE request_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, requestId);
            stmt.executeUpdate();
        }
    }
}