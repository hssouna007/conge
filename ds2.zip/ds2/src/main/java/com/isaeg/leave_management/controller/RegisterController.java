package com.isaeg.leave_management.controller;
import com.isaeg.leave_management.dao.UserDAO;
import com.isaeg.leave_management.dao.UserDAOImpl;
import com.isaeg.leave_management.model.User;
import com.isaeg.leave_management.util.PasswordUtil;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
public class RegisterController implements Initializable {
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private ChoiceBox<String> roleChoiceBox;
    @FXML private TextField firstNameField;
    @FXML private TextField lastNameField;
    @FXML private TextField emailField;
    @FXML private Label errorLabel;
    private final UserDAO userDAO = new UserDAOImpl();
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Optional: Initialize ChoiceBox in Java as a fallback
        roleChoiceBox.setItems(FXCollections.observableArrayList("TEACHER", "STAFF", "HR", "ADMIN"));
    }
    @FXML
    private void handleRegister(ActionEvent event) {
        String username = usernameField.getText().trim();
        String password = passwordField.getText();
        String role = roleChoiceBox.getValue();
        String firstName = firstNameField.getText().trim();
        String lastName = lastNameField.getText().trim();
        String email = emailField.getText().trim();
        if (username.isEmpty() || password.isEmpty() || role == null || firstName.isEmpty() || lastName.isEmpty() || email.isEmpty()) {
            errorLabel.setText("All fields are required");
            return;
        }
        try {
            if (userDAO.getUserByUsername(username) != null) {
                errorLabel.setText("Username already exists");
                return;
            }
            String hashedPassword = PasswordUtil.hashPassword(password);
            User user = new User(0, username, hashedPassword, role, firstName, lastName, email);
            userDAO.createUser(user);
            errorLabel.setText("Registration successful! Returning to login...");
            handleBack(event);
        } catch (SQLException e) {
            errorLabel.setText("Registration failed: " + e.getMessage());
        }
    }
    @FXML
    private void handleBack(ActionEvent event) {
        try {
            Parent loginParent = FXMLLoader.load(getClass().getResource("/com/isaeg/leave_management/fxml/login.fxml"));
            Scene loginScene = new Scene(loginParent, 600, 400);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(loginScene);
            stage.setTitle("Leave Management System - Login");
            stage.show();
        } catch (IOException e) {
            errorLabel.setText("Error loading login: " + e.getMessage());
        }
    }
}