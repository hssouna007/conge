package com.isaeg.leave_management.controller;
import com.isaeg.leave_management.dao.LeaveRequestDAO;
import com.isaeg.leave_management.dao.LeaveRequestDAOImpl;
import com.isaeg.leave_management.model.LeaveRequest;
import com.isaeg.leave_management.model.User;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
public class LeaveHistoryController {
    @FXML private TableView<LeaveRequest> leaveTable;
    @FXML private TableColumn<LeaveRequest, String> leaveTypeColumn;
    @FXML private TableColumn<LeaveRequest, LocalDate> startDateColumn;
    @FXML private TableColumn<LeaveRequest, LocalDate> endDateColumn;
    @FXML private TableColumn<LeaveRequest, String> statusColumn;
    @FXML private TableColumn<LeaveRequest, String> reasonColumn;
    @FXML private TableColumn<LeaveRequest, String> rejectionReasonColumn;
    @FXML private TableColumn<LeaveRequest, LocalDateTime> submittedAtColumn;
    @FXML private TableColumn<LeaveRequest, LocalDateTime> processedAtColumn;
    @FXML private Label errorLabel;
    private final LeaveRequestDAO leaveRequestDAO = new LeaveRequestDAOImpl();
    private User currentUser;
    public void setUser(User user) {
        this.currentUser = user;
        loadLeaveHistory();
    }
    private void loadLeaveHistory() {
        try {
            List<LeaveRequest> requests = leaveRequestDAO.getLeaveRequestsByUserId(currentUser.getId());
            leaveTypeColumn.setCellValueFactory(new PropertyValueFactory<>("leaveType"));
            startDateColumn.setCellValueFactory(new PropertyValueFactory<>("startDate"));
            endDateColumn.setCellValueFactory(new PropertyValueFactory<>("endDate"));
            statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
            reasonColumn.setCellValueFactory(new PropertyValueFactory<>("reason"));
            rejectionReasonColumn.setCellValueFactory(new PropertyValueFactory<>("rejectionReason"));
            submittedAtColumn.setCellValueFactory(new PropertyValueFactory<>("submittedAt"));
            processedAtColumn.setCellValueFactory(new PropertyValueFactory<>("processedAt"));
            leaveTable.setItems(FXCollections.observableArrayList(requests));
        } catch (SQLException e) {
            errorLabel.setText("Error loading history: " + e.getMessage());
        }
    }
    @FXML
    private void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/isaeg/leave_management/fxml/dashboard.fxml"));
            Parent dashboardParent = loader.load();
            DashboardController controller = loader.getController();
            controller.setUserInfo(currentUser.getUsername(), currentUser.getRole());
            Scene dashboardScene = new Scene(dashboardParent, 800, 600);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(dashboardScene);
            stage.setTitle("Leave Management System - Dashboard");
            stage.show();
        } catch (IOException e) {
            errorLabel.setText("Error loading dashboard: " + e.getMessage());
        }
    }
}