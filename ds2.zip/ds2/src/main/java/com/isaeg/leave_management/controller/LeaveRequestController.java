package com.isaeg.leave_management.controller;
import com.isaeg.leave_management.dao.LeaveRequestDAO;
import com.isaeg.leave_management.dao.LeaveRequestDAOImpl;
import com.isaeg.leave_management.model.LeaveRequest;
import com.isaeg.leave_management.model.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
public class LeaveRequestController {
    @FXML private ChoiceBox<String> leaveTypeChoiceBox;
    @FXML private DatePicker startDatePicker;
    @FXML private DatePicker endDatePicker;
    @FXML private TextField reasonField;
    @FXML private Label errorLabel;
    @FXML private Label successLabel;
    private final LeaveRequestDAO leaveRequestDAO = new LeaveRequestDAOImpl();
    private User currentUser;
    public void setUser(User user) {
        this.currentUser = user;
    }
    @FXML
    private void handleSubmit(ActionEvent event) {
        String leaveType = leaveTypeChoiceBox.getValue();
        LocalDate startDate = startDatePicker.getValue();
        LocalDate endDate = startDatePicker.getValue();
        String reason = reasonField.getText().trim();
        if (leaveType == null || startDate == null || endDate == null || reason.isEmpty()) {
            errorLabel.setText("All fields are required");
            return;
        }
        if (startDate.isAfter(endDate)) {
            errorLabel.setText("Start date must be before end date");
            return;
        }
        if (startDate.isBefore(LocalDate.now())) {
            errorLabel.setText("Start date cannot be in the past");
            return;
        }
        try {
            LeaveRequest request = new LeaveRequest(
                    0, // ID auto-generated
                    currentUser.getId(),
                    leaveType,
                    startDate,
                    endDate,
                    reason,
                    "PENDING",
                    null, // rejectionReason
                    null, // submittedAt (set by DB)
                    null  // processedAt
            );
            leaveRequestDAO.createLeaveRequest(request);
            successLabel.setText("Leave request submitted successfully!");
            errorLabel.setText("");
            // Clear form
            leaveTypeChoiceBox.setValue(null);
            startDatePicker.setValue(null);
            endDatePicker.setValue(null);
            reasonField.clear();
        } catch (SQLException e) {
            errorLabel.setText("Submission failed: " + e.getMessage());
            successLabel.setText("");
        }
    }
    @FXML
    private void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/isaeg/leave_management/fxml/dashboard.fxml"));
            Parent dashboardParent = loader.load();
            DashboardController controller = loader.getController();
            controller.setUserInfo(currentUser.getUsername(), currentUser.getRole());
            Scene dashboardScene = new Scene(dashboardParent, 800, 600);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(dashboardScene);
            stage.setTitle("Leave Management System - Dashboard");
            stage.show();
        } catch (IOException e) {
            errorLabel.setText("Error loading dashboard: " + e.getMessage());
        }
    }
}