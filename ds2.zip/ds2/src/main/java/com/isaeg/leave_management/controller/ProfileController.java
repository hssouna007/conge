package com.isaeg.leave_management.controller;
import com.isaeg.leave_management.dao.UserDAO;
import com.isaeg.leave_management.dao.UserDAOImpl;
import com.isaeg.leave_management.model.User;
import com.isaeg.leave_management.util.PasswordUtil;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;
import java.io.IOException;
import java.sql.SQLException;
public class ProfileController {
    @FXML private TextField usernameField;
    @FXML private TextField roleField;
    @FXML private PasswordField passwordField;
    @FXML private TextField firstNameField;
    @FXML private TextField lastNameField;
    @FXML private TextField emailField;
    @FXML private Label errorLabel;
    @FXML private Label successLabel;
    private final UserDAO userDAO = new UserDAOImpl();
    private User currentUser;
    public void setUser(User user) {
        this.currentUser = user;
        usernameField.setText(user.getUsername());
        roleField.setText(user.getRole());
        firstNameField.setText(user.getFirstName());
        lastNameField.setText(user.getLastName());
        emailField.setText(user.getEmail());
    }
    @FXML
    private void handleUpdate(ActionEvent event) {
        String password = passwordField.getText().trim();
        String firstName = firstNameField.getText().trim();
        String lastName = lastNameField.getText().trim();
        String email = emailField.getText().trim();
        if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty()) {
            errorLabel.setText("First name, last name, and email are required");
            return;
        }
        try {
            User updatedUser = new User(
                    currentUser.getId(),
                    currentUser.getUsername(),
                    password.isEmpty() ? currentUser.getPassword() : PasswordUtil.hashPassword(password),
                    currentUser.getRole(),
                    firstName,
                    lastName,
                    email
            );
            userDAO.updateUser(updatedUser);
            successLabel.setText("Profile updated successfully!");
            errorLabel.setText("");
        } catch (SQLException e) {
            errorLabel.setText("Update failed: " + e.getMessage());
            successLabel.setText("");
        }
    }
    @FXML
    private void handleDelete(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to delete your account?", ButtonType.YES, ButtonType.NO);
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.YES) {
                try {
                    userDAO.deleteUser(currentUser.getId());
                    // Navigate to login
                    Parent loginParent = FXMLLoader.load(getClass().getResource("/com/isaeg/leave_management/fxml/login.fxml"));
                    Scene loginScene = new Scene(loginParent, 600, 400);
                    Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                    stage.setScene(loginScene);
                    stage.setTitle("Leave Management System - Login");
                    stage.show();
                } catch (SQLException e) {
                    errorLabel.setText("Deletion failed: " + e.getMessage());
                } catch (IOException e) {
                    errorLabel.setText("Error loading login: " + e.getMessage());
                }
            }
        });
    }
    @FXML
    private void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/isaeg/leave_management/fxml/dashboard.fxml"));
            Parent dashboardParent = loader.load();
            DashboardController controller = loader.getController();
            controller.setUserInfo(currentUser.getUsername(), currentUser.getRole());
            Scene dashboardScene = new Scene(dashboardParent, 800, 600);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(dashboardScene);
            stage.setTitle("Leave Management System - Dashboard");
            stage.show();
        } catch (IOException e) {
            errorLabel.setText("Error loading dashboard: " + e.getMessage());
        }
    }
}