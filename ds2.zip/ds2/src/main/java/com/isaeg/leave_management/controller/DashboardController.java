package com.isaeg.leave_management.controller;
import com.isaeg.leave_management.dao.UserDAO;
import com.isaeg.leave_management.dao.UserDAOImpl;
import com.isaeg.leave_management.model.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import java.io.IOException;
import java.sql.SQLException;
public class DashboardController {
    @FXML private Label welcomeLabel;
    @FXML private Button submitLeaveButton;
    @FXML private Button viewRequestsButton;
    @FXML private Button viewBalancesButton;
    @FXML private Button approveRequestsButton;
    @FXML private Button manageUsersButton;
    @FXML private Button profileButton;
    private User currentUser;
    private final UserDAO userDAO = new UserDAOImpl();
    public void setUserInfo(String username, String role) {
        try {
            currentUser = userDAO.getUserByUsername(username);
            if (currentUser == null) {
                welcomeLabel.setText("Error: User not found");
                return;
            }
            welcomeLabel.setText("Welcome, " + username + " (" + role + ")");
            System.out.println("Setting dashboard for role: " + role); // Debug
            switch (role) {
                case "TEACHER":
                case "STAFF":
                    submitLeaveButton.setVisible(true);
                    viewRequestsButton.setVisible(true);
                    viewBalancesButton.setVisible(true);
                    break;
                case "HR":
                    approveRequestsButton.setVisible(true);
                    viewBalancesButton.setVisible(true);
                    break;
                case "ADMIN":
                    submitLeaveButton.setVisible(true);
                    viewRequestsButton.setVisible(true);
                    viewBalancesButton.setVisible(true);
                    approveRequestsButton.setVisible(true);
                    manageUsersButton.setVisible(true);
                    break;
                default:
                    welcomeLabel.setText("Error: Invalid role");
            }
        } catch (SQLException e) {
            welcomeLabel.setText("Error loading user: " + e.getMessage());
            System.err.println("SQLException in setUserInfo: " + e.getMessage());
        }
    }
    @FXML
    private void handleProfile(ActionEvent event) {
        try {
            System.out.println("Loading profile.fxml"); // Debug
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/isaeg/leave_management/fxml/profile.fxml"));
            Parent profileParent = loader.load();
            ProfileController controller = loader.getController();
            controller.setUser(currentUser);
            Scene profileScene = new Scene(profileParent, 600, 400);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(profileScene);
            stage.setTitle("Leave Management System - Profile");
            stage.show();
        } catch (IOException e) {
            welcomeLabel.setText("Error loading profile: " + e.getMessage());
            System.err.println("IOException in handleProfile: " + e.getMessage());
        }
    }
    @FXML
    private void handleSubmitLeave(ActionEvent event) {
        try {
            System.out.println("Loading leave_request.fxml"); // Debug
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/isaeg/leave_management/fxml/leave_request.fxml"));
            Parent leaveParent = loader.load();
            LeaveRequestController controller = loader.getController();
            controller.setUser(currentUser);
            Scene leaveScene = new Scene(leaveParent, 600, 400);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(leaveScene);
            stage.setTitle("Leave Management System - Submit Leave");
            stage.show();
        } catch (IOException e) {
            welcomeLabel.setText("Error loading leave request: " + e.getMessage());
            System.err.println("IOException in handleSubmitLeave: " + e.getMessage());
        }
    }
    @FXML
    private void handleViewRequests(ActionEvent event) {
        try {
            System.out.println("Loading leave_history.fxml"); // Debug
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/isaeg/leave_management/fxml/leave_history.fxml"));
            Parent historyParent = loader.load();
            LeaveHistoryController controller = loader.getController();
            controller.setUser(currentUser);
            Scene historyScene = new Scene(historyParent, 800, 600);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(historyScene);
            stage.setTitle("Leave Management System - Leave History");
            stage.show();
        } catch (IOException e) {
            welcomeLabel.setText("Error loading leave history: " + e.getMessage());
            System.err.println("IOException in handleViewRequests: " + e.getMessage());
        }
    }
    @FXML
    private void handleViewBalances(ActionEvent event) {
        try {
            System.out.println("Loading view_balances.fxml"); // Debug
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/isaeg/leave_management/fxml/view_balances.fxml"));
            Parent balancesParent = loader.load();
            ViewBalancesController controller = loader.getController();
            controller.setUser(currentUser);
            Scene balancesScene = new Scene(balancesParent, 600, 400);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(balancesScene);
            stage.setTitle("Leave Management System - View Balances");
            stage.show();
        } catch (IOException e) {
            welcomeLabel.setText("Error loading balances: " + e.getMessage());
            System.err.println("IOException in handleViewBalances: " + e.getMessage());
        }
    }
    @FXML
    private void handleApproveRequests(ActionEvent event) {
        try {
            System.out.println("Loading approve_requests.fxml"); // Debug
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/isaeg/leave_management/fxml/approve_requests.fxml"));
            Parent approveParent = loader.load();
            ApproveRequestsController controller = loader.getController();
            controller.setUser(currentUser);
            Scene approveScene = new Scene(approveParent, 800, 600);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(approveScene);
            stage.setTitle("Leave Management System - Approve Requests");
            stage.show();
        } catch (IOException e) {
            welcomeLabel.setText("Error loading approve requests: " + e.getMessage());
            System.err.println("IOException in handleApproveRequests: " + e.getMessage());
        }
    }
    @FXML
    private void handleManageUsers(ActionEvent event) {
        try {
            System.out.println("Loading manage_users.fxml"); // Debug
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/isaeg/leave_management/fxml/manage_users.fxml"));
            Parent manageUsersParent = loader.load();
            ManageUsersController controller = loader.getController();
            controller.setUser(currentUser);
            Scene manageUsersScene = new Scene(manageUsersParent, 800, 600);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(manageUsersScene);
            stage.setTitle("Leave Management System - Manage Users");
            stage.show();
        } catch (IOException e) {
            welcomeLabel.setText("Error loading manage users: " + e.getMessage());
            System.err.println("IOException in handleManageUsers: " + e.getMessage());
        }
    }
    @FXML
    private void handleLogout(ActionEvent event) {
        try {
            System.out.println("Logging out"); // Debug
            Parent loginParent = FXMLLoader.load(getClass().getResource("/com/isaeg/leave_management/fxml/login.fxml"));
            Scene loginScene = new Scene(loginParent, 600, 400);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(loginScene);
            stage.setTitle("Leave Management System - Login");
            stage.show();
        } catch (IOException e) {
            welcomeLabel.setText("Error logging out: " + e.getMessage());
            System.err.println("IOException in handleLogout: " + e.getMessage());
        }
    }
}