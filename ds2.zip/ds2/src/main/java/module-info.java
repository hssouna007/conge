module com.isaeg.leave_management {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;
    requires java.sql;
    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires net.synedra.validatorfx;
    requires org.kordamp.ikonli.javafx;
    requires org.kordamp.bootstrapfx.core;
    requires eu.hansolo.tilesfx;
    requires com.almasb.fxgl.all;

    requires jbcrypt;

    opens com.isaeg.leave_management.model to javafx.base,javafx.fxml;
    opens com.isaeg.leave_management.controller to javafx.fxml;
    exports com.isaeg.leave_management;
}