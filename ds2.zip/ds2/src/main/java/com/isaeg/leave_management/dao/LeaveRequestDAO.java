package com.isaeg.leave_management.dao;
import com.isaeg.leave_management.model.LeaveRequest;
import java.sql.SQLException;
import java.util.List;
public interface LeaveRequestDAO {
    void createLeaveRequest(LeaveRequest request) throws SQLException;
    LeaveRequest getLeaveRequestById(int requestId) throws SQLException;
    List<LeaveRequest> getLeaveRequestsByUserId(int userId) throws SQLException;
    List<LeaveRequest> getAllPendingRequests() throws SQLException;
    void updateLeaveRequest(LeaveRequest request) throws SQLException;
    void deleteLeaveRequest(int requestId) throws SQLException;
}