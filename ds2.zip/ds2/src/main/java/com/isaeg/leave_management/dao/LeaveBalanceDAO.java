package com.isaeg.leave_management.dao;
import com.isaeg.leave_management.model.LeaveBalance;
import java.sql.SQLException;
import java.util.List;
public interface LeaveBalanceDAO {
    List<LeaveBalance> getLeaveBalancesByUserId(int userId) throws SQLException;
}